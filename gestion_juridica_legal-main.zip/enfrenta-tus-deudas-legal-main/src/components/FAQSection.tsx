import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "¿Realmente la primera consulta es gratuita?",
    answer: "Sí, completamente gratuita y sin compromiso. En esta consulta evaluamos tu caso, te explicamos tus opciones legales y te damos un plan de acción claro. Solo pagas si decides que te representemos."
  },
  {
    question: "¿Cuánto tiempo demora el proceso de renegociación?",
    answer: "Generalmente entre 30 a 90 días, dependiendo de la cantidad de acreedores y la complejidad del caso. Durante este tiempo mantenemos comunicación constante contigo sobre los avances."
  },
  {
    question: "¿Pueden detener embargos que ya están en proceso?",
    answer: "Sí, podemos solicitar la suspensión de embargos mientras negociamos con tus acreedores. También podemos impugnar embargos irregulares y defender tus bienes esenciales."
  },
  {
    question: "¿Qué pasa si no puedo pagar las cuotas acordadas?",
    answer: "Siempre negociamos cuotas acordes a tu capacidad real de pago. Si tu situación cambia, podemos renegociar nuevamente. Nuestro objetivo es que puedas cumplir sosteniblemente."
  },
  {
    question: "¿El proceso de quiebra personal afecta mi trabajo?",
    answer: "No, la quiebra personal no afecta tu trabajo actual ni tu capacidad laboral. Es un proceso confidencial que te permite liberarte de deudas incobrables y empezar de nuevo financieramente."
  },
  {
    question: "¿Cuánto tiempo tarda en limpiarse mi DICOM?",
    answer: "Una vez liquidadas las deudas, el proceso de limpieza en DICOM puede tomar entre 3 a 6 meses. Te ayudamos con todos los trámites necesarios para acelerar este proceso."
  },
  {
    question: "¿Qué documentos necesito para empezar?",
    answer: "Necesitarás: informe DICOM actualizado, liquidaciones de sueldo de los últimos 3 meses, cartola de cuentas corrientes, y cualquier documento relacionado con tus deudas. Te ayudamos a reunir todo lo necesario."
  },
  {
    question: "¿Trabajan con todo tipo de deudas?",
    answer: "Sí, trabajamos con deudas bancarias, tarjetas de crédito, casas comerciales, créditos de consumo, automotrices, hipotecarios, y deudas con el fisco. Cada caso requiere una estrategia específica."
  }
];

export const FAQSection = () => {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6">
            <HelpCircle className="h-5 w-5 text-primary" />
            <span className="text-primary font-semibold">Preguntas Frecuentes</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Resolvemos todas <span className="text-primary">tus dudas</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Las preguntas más frecuentes de nuestros clientes sobre el proceso 
            de solución de deudas y nuestros servicios legales.
          </p>
        </div>

        {/* FAQ Grid */}
        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card border border-border/40 rounded-lg px-6 data-[state=open]:shadow-medium transition-all duration-300"
              >
                <AccordionTrigger className="text-left font-semibold text-lg hover:text-primary transition-colors py-6 [&[data-state=open]]:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-card border border-border/40 rounded-2xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              ¿Tienes otra pregunta?
            </h3>
            <p className="text-muted-foreground mb-6">
              Nuestros abogados especialistas están disponibles para resolver 
              cualquier duda específica sobre tu caso particular.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="tel:+56951769304" 
                className="inline-flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Llamar: +56 9 5176 9304
              </a>
              <a 
                href="https://wa.me/56951769304" 
                className="inline-flex items-center justify-center bg-accent text-accent-foreground hover:bg-accent/90 px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};