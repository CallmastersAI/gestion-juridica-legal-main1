import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, CheckCircle, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const LeadForm = () => {
  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    telefono: "",
    email: ""
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here would be the actual form submission logic
    toast({
      title: "¡Formulario enviado!",
      description: "Nos contactaremos contigo en las próximas horas.",
      className: "bg-accent text-accent-foreground"
    });
  };

  const handleWhatsAppClick = async () => {
    const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Inicio_whatsapp";
    
    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          timestamp: new Date().toISOString(),
          source: "Lead Form",
          action: "whatsapp_click",
          page: window.location.href
        }),
      });

      window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank");
    } catch (error) {
      console.error("Error al conectar webhook:", error);
      window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <Card className="w-full max-w-md bg-card shadow-strong border-border/20">
      <CardHeader className="text-center">
        <CardTitle className="text-xl font-bold text-foreground">
          ¡Hablemos!
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Tu primera consulta es <span className="text-accent font-semibold">sin costo</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="nombre" className="text-sm font-medium">
                Nombre*
              </Label>
              <Input
                id="nombre"
                name="nombre"
                value={formData.nombre}
                onChange={handleChange}
                placeholder="Tu nombre"
                required
                className="bg-background"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apellido" className="text-sm font-medium">
                Apellido*
              </Label>
              <Input
                id="apellido"
                name="apellido"
                value={formData.apellido}
                onChange={handleChange}
                placeholder="Tu apellido"
                required
                className="bg-background"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="telefono" className="text-sm font-medium">
              Teléfono Celular*
            </Label>
            <Input
              id="telefono"
              name="telefono"
              type="tel"
              value={formData.telefono}
              onChange={handleChange}
              placeholder="+56 9 XXXX XXXX"
              required
              className="bg-background"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-sm font-medium">
              Correo electrónico*
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
              className="bg-background"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button 
              type="button"
              onClick={() => window.location.href = 'tel:+56951769304'}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6"
            >
              <Phone className="mr-2 h-5 w-5" />
              Llamar Ahora: +56 9 5176 9304
            </Button>
            
            <Button 
              type="button"
              onClick={handleWhatsAppClick}
              className="bg-accent hover:bg-accent/90 text-white font-semibold py-6"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              Consulta WhatsApp
            </Button>
          </div>

          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <CheckCircle className="h-4 w-4 text-accent" />
            <span>Respuesta inmediata por WhatsApp</span>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};