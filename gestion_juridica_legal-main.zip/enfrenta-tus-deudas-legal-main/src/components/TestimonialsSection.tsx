import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "María González",
    location: "Santiago",
    rating: 5,
    text: "Tenía deudas por más de $15 millones y gracias a Gestión Jurídica logré renegociar y reducir mi deuda a $6 millones. Ahora puedo dormir tranquila.",
    result: "Reducción del 60% en deudas"
  },
  {
    name: "Carlos Martínez",
    location: "Valparaíso", 
    rating: 5,
    text: "Estaba con proceso de embargo y estos abogados me salvaron. Lograron detener todo y negociar un plan de pagos que sí puedo cumplir.",
    result: "Embargo detenido exitosamente"
  },
  {
    name: "Ana Morales",
    location: "Concepción",
    rating: 5,
    text: "El proceso de quiebra personal fue más rápido de lo que esperaba. En 4 meses me liberé de todas mis deudas y pude empezar de nuevo.",
    result: "Liberación total de deudas"
  },
  {
    name: "Roberto Silva",
    location: "La Serena",
    rating: 5,
    text: "Excelente atención y muy profesionales. Me explicaron todo paso a paso y cumplieron lo que prometieron. 100% recomendados.",
    result: "DICOM limpio en 6 meses"
  }
];

export const TestimonialsSection = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-accent/10 px-4 py-2 rounded-full mb-6">
            <Star className="h-5 w-5 text-accent fill-accent" />
            <span className="text-accent font-semibold">Testimonios Reales</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Más de <span className="text-primary">100 chilenos</span> han recuperado 
            <span className="block mt-2">su tranquilidad financiera</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Conoce las historias reales de personas que lograron liberarse de sus deudas 
            con nuestro acompañamiento legal profesional.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="relative bg-card border-border/40 hover:shadow-medium transition-all duration-300">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <Quote className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <div className="flex gap-1 mb-3">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-secondary fill-secondary" />
                      ))}
                    </div>
                    <p className="text-foreground text-lg leading-relaxed mb-6">
                      "{testimonial.text}"
                    </p>
                  </div>
                </div>
                
                <div className="border-t border-border/40 pt-6">
                  <div className="flex justify-between items-end">
                    <div>
                      <h4 className="font-bold text-foreground text-lg">
                        {testimonial.name}
                      </h4>
                      <p className="text-muted-foreground">
                        {testimonial.location}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-semibold">
                        {testimonial.result}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Badge */}
        <div className="text-center">
          <div className="inline-flex items-center gap-4 bg-muted/50 px-8 py-6 rounded-2xl border border-border/40">
            <div className="flex -space-x-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="w-10 h-10 bg-gradient-cta rounded-full border-2 border-background flex items-center justify-center text-white font-bold text-sm">
                  {String.fromCharCode(65 + i)}
                </div>
              ))}
            </div>
            <div className="text-left">
              <div className="flex gap-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-secondary fill-secondary" />
                ))}
              </div>
              <p className="text-foreground font-semibold">
                4.9/5 basado en +200 reseñas
              </p>
              <p className="text-muted-foreground text-sm">
                Clientes satisfechos con nuestro servicio
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};