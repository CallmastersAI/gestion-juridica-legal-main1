import { Scale, Shield, Phone, Mail, MapPin, Clock } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export const Footer = () => {
  return (
    <footer className="bg-legal-navy text-white">
      
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 p-2 bg-secondary/10 rounded-lg">
                <Shield className="h-6 w-6 text-secondary" />
                <Scale className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Gestión Jurídica</h3>
                <p className="text-secondary text-sm font-medium">
                  Tu tranquilidad financiera es nuestra misión
                </p>
              </div>
            </div>
            <p className="text-white/80 leading-relaxed">
              Estudio jurídico especializado en soluciones de deuda con más de 15 años 
              de experiencia ayudando a chilenos a recuperar su estabilidad financiera.
            </p>
            <div className="flex gap-4">
              <div className="bg-secondary/10 p-2 rounded-lg">
                <div className="text-secondary font-bold text-lg">+95%</div>
                <div className="text-white/70 text-xs">Casos Exitosos</div>
              </div>
              <div className="bg-secondary/10 p-2 rounded-lg">
                <div className="text-secondary font-bold text-lg">1000+</div>
                <div className="text-white/70 text-xs">Clientes</div>
              </div>
            </div>
          </div>

          {/* Services Column */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-secondary">Nuestros Servicios</h4>
            <ul className="space-y-3">
              <li>
                <a href="#renegociacion" className="text-white/80 hover:text-secondary transition-colors">
                  Renegociación de Deudas
                </a>
              </li>
              <li>
                <a href="#defensa" className="text-white/80 hover:text-secondary transition-colors">
                  Defensa Judicial
                </a>
              </li>
              <li>
                <a href="#quiebra" className="text-white/80 hover:text-secondary transition-colors">
                  Quiebra Personal
                </a>
              </li>
              <li>
                <a href="#rehabilitacion" className="text-white/80 hover:text-secondary transition-colors">
                  Rehabilitación Comercial
                </a>
              </li>
              <li>
                <a href="#dicom" className="text-white/80 hover:text-secondary transition-colors">
                  Limpieza DICOM
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-secondary">Contacto Directo</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-secondary flex-shrink-0" />
                <div>
                  <a href="tel:+56951769304" className="font-medium hover:text-secondary transition-colors">
                    +56 9 5176 9304
                  </a>
                  <p className="text-white/70 text-sm">Línea directa 24/7</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-secondary flex-shrink-0" />
                <div>
                  <a href="mailto:contacto@gestionjuridica.cl" className="font-medium hover:text-secondary transition-colors">
                    contacto@gestionjuridica.cl
                  </a>
                  <p className="text-white/70 text-sm">Respuesta en 2 horas</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-secondary flex-shrink-0" />
                <div>
                  <p className="font-medium">Santiago, Chile</p>
                  <p className="text-white/70 text-sm">Atención presencial y remota</p>
                </div>
              </div>
            </div>
          </div>

          {/* Hours & Legal Column */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold text-secondary">Horarios de Atención</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-secondary flex-shrink-0" />
                <div>
                  <p className="font-medium">Lun - Vie: 8:00 - 20:00</p>
                  <p className="text-white/70 text-sm">Sáb: 9:00 - 14:00</p>
                  <p className="text-white/70 text-sm">Dom: Emergencias</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h5 className="font-medium text-secondary">Información Legal</h5>
              <ul className="space-y-2 text-sm text-white/80">
                <li>RUT: XX.XXX.XXX-X</li>
                <li>Registro Colegio Abogados</li>
                <li>Especialistas Certificados</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-white/20" />

      {/* Bottom Footer */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-white/70 text-sm">
            © 2024 Gestión Jurídica. Todos los derechos reservados.
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#privacy" className="text-white/70 hover:text-secondary transition-colors">
              Política de Privacidad
            </a>
            <a href="#terms" className="text-white/70 hover:text-secondary transition-colors">
              Términos y Condiciones
            </a>
            <a href="#cookies" className="text-white/70 hover:text-secondary transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};