import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Scale, 
  Shield, 
  TrendingUp, 
  Users, 
  CheckCircle,
  Phone,
  MessageCircle
} from "lucide-react";

const handleWhatsAppClick = async () => {
  const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Inicio_whatsapp";
  
  try {
    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        source: "Services Section",
        action: "whatsapp_click",
        page: window.location.href
      }),
    });

    window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank");
  } catch (error) {
    console.error("Error al conectar webhook:", error);
    window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank");
  }
};

const services = [
  {
    icon: FileText,
    title: "Renegociación de Deudas",
    description: "Negociamos directamente con tus acreedores para obtener las mejores condiciones de pago.",
    benefits: ["Reducción hasta 70% deuda", "Cuotas acordes a tu presupuesto", "Sin embargos"]
  },
  {
    icon: Scale,
    title: "Defensa Judicial",
    description: "Te representamos legalmente ante demandas y procesos judiciales por deudas.",
    benefits: ["Representación completa", "Estrategia personalizada", "Protección de bienes"]
  },
  {
    icon: Shield,
    title: "Quiebra Personal",
    description: "Tramitación completa de liquidación voluntaria para liberarte definitivamente.",
    benefits: ["Liberación total deudas", "Proceso rápido y seguro", "Nuevo comienzo financiero"]
  },
  {
    icon: TrendingUp,
    title: "Rehabilitación Comercial",
    description: "Estrategias para limpiar tu historial crediticio y recuperar tu capacidad de endeudamiento.",
    benefits: ["Limpieza DICOM", "Mejora score crediticio", "Acceso a nuevos créditos"]
  }
];

export const ServicesSection = () => {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            ¿Sobreendeudado? Tenemos una 
            <span className="text-primary block mt-2">solución legal a tu medida</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Nuestros abogados especialistas te ayudan a encontrar la mejor estrategia 
            según tu situación particular y presupuesto familiar.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="group hover:shadow-medium transition-all duration-300 border-border/40">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-xl font-bold text-foreground">
                        {service.title}
                      </CardTitle>
                    </div>
                  </div>
                  <CardDescription className="text-muted-foreground text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {service.benefits.map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                        <span className="text-foreground font-medium">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-success rounded-2xl p-8 lg:p-12 text-center text-white">
          <div className="max-w-3xl mx-auto space-y-6">
            <Users className="h-16 w-16 mx-auto text-white/90" />
            <h3 className="text-3xl lg:text-4xl font-bold">
              ¡No enfrentes tus deudas solo!
            </h3>
            <p className="text-xl text-white/90">
              Nuestro equipo de abogados especialistas está listo para ayudarte. 
              Primera consulta completamente gratuita y sin compromiso.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
              <Button 
                size="lg"
                onClick={() => window.location.href = 'tel:+56951769304'}
                className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8 py-4"
              >
                <Phone className="mr-2 h-5 w-5" />
                Llamar Ahora: +56 9 5176 9304
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={handleWhatsAppClick}
                className="border-white text-white hover:bg-white/10 font-semibold text-lg px-8 py-4"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Consulta WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};