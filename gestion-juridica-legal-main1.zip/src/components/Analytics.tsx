"use client"

import React from "react"

/**
 * Analytics Component
 * Handles tracking of user interactions for SEM and SEO optimization
 * Logs key events: form submissions, CTA clicks, page views
 */

export const trackEvent = async (eventName: string, eventData: Record<string, any>) => {
  try {
    // Track to webhook for business intelligence
    const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Analytics_evento"

    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        event: eventName,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href,
        referrer: document.referrer,
        ...eventData,
      }),
    })
  } catch (error) {
    console.error("[Analytics] Error tracking event:", error)
  }
}

export const trackPageView = () => {
  trackEvent("page_view", {
    title: document.title,
    path: window.location.pathname,
  })
}

export const trackFormSubmission = (formName: string, fields: string[]) => {
  trackEvent("form_submission", {
    formName,
    fields,
    timestamp: new Date().toISOString(),
  })
}

export const trackCTAClick = (ctaName: string, action: string) => {
  trackEvent("cta_click", {
    ctaName,
    action,
    timestamp: new Date().toISOString(),
  })
}

export const trackScrollDepth = (depth: number) => {
  trackEvent("scroll_depth", {
    depth,
    timestamp: new Date().toISOString(),
  })
}

export const Analytics = () => {
  React.useEffect(() => {
    // Track page view
    trackPageView()

    // Track scroll depth
    let maxScroll = 0
    const handleScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrolled = (window.scrollY / scrollHeight) * 100
      if (scrolled > maxScroll) {
        maxScroll = scrolled
        if (maxScroll === 100) {
          trackScrollDepth(100)
        } else if (maxScroll >= 75) {
          trackScrollDepth(75)
        } else if (maxScroll >= 50) {
          trackScrollDepth(50)
        } else if (maxScroll >= 25) {
          trackScrollDepth(25)
        }
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })

    // Track time on page
    const startTime = Date.now()
    const handleBeforeUnload = () => {
      const timeOnPage = (Date.now() - startTime) / 1000
      trackEvent("time_on_page", {
        seconds: Math.round(timeOnPage),
      })
    }

    window.addEventListener("beforeunload", handleBeforeUnload)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      window.removeEventListener("beforeunload", handleBeforeUnload)
    }
  }, [])

  return null
}
