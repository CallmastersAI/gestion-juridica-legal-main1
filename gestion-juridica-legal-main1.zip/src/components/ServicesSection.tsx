"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { FileText, Scale, Shield, TrendingUp, Users, Phone, MessageCircle } from "lucide-react"
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver"

const handleWhatsAppClick = async () => {
  const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Inicio_whatsapp"

  try {
    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        source: "Services Section",
        action: "whatsapp_click",
        page: window.location.href,
      }),
    })

    window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank")
  } catch (error) {
    console.error("Error al conectar webhook:", error)
    window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank")
  }
}

const services = [
  {
    icon: FileText,
    title: "Renegociación de Deudas",
    description: "Negociamos directamente con tus acreedores para obtener las mejores condiciones de pago.",
    benefits: ["Reducción hasta 70% deuda", "Cuotas acordes a tu presupuesto", "Sin embargos"],
  },
  {
    icon: Scale,
    title: "Defensa Judicial",
    description: "Te representamos legalmente ante demandas y procesos judiciales por deudas.",
    benefits: ["Representación completa", "Estrategia personalizada", "Protección de bienes"],
  },
  {
    icon: Shield,
    title: "Quiebra Personal",
    description: "Tramitación completa de liquidación voluntaria para liberarte definitivamente.",
    benefits: ["Liberación total deudas", "Proceso rápido y seguro", "Nuevo comienzo financiero"],
  },
  {
    icon: TrendingUp,
    title: "Rehabilitación Comercial",
    description: "Estrategias para limpiar tu historial crediticio y recuperar tu capacidad de endeudamiento.",
    benefits: ["Limpieza DICOM", "Mejora score crediticio", "Acceso a nuevos créditos"],
  },
]

export const ServicesSection = () => {
  const { elementRef, isVisible } = useIntersectionObserver()

  return (
    <section id="servicios" ref={elementRef as React.RefObject<HTMLElement>} className="py-24 bg-muted/30 scroll-mt-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className={`text-center mb-16 slide-in-top ${isVisible ? "visible" : ""}`}>
          <div className="inline-block mb-4">
            <span className="bg-primary/10 text-primary px-4 py-1 rounded-full text-sm font-semibold">
              Nuestras Soluciones
            </span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            ¿Sobreendeudado? Tenemos una
            <span className="text-primary block mt-2">solución legal a tu medida</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Nuestros abogados especialistas te ayudan a encontrar la mejor estrategia según tu situación particular y
            presupuesto familiar. Cada caso es único y merece una solución personalizada.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon
            return (
              <div key={index} className={`group slide-in-top ${isVisible ? "visible" : ""} stagger-${index + 1}`}>
                <div className="h-full bg-white dark:bg-card rounded-2xl border border-border/40 p-8 hover:shadow-lg hover:border-primary/20 transition-all duration-300 cursor-pointer hover:-translate-y-1">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                      {service.title}
                    </h3>
                  </div>
                  <p className="text-muted-foreground text-base mb-6 leading-relaxed">{service.description}</p>
                  <div className="space-y-3">
                    {service.benefits.map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className="h-2 w-2 bg-accent rounded-full flex-shrink-0" />
                        <span className="text-foreground font-medium">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* CTA Section */}
        <div
          className={`bg-gradient-success rounded-2xl p-8 lg:p-12 text-center text-white slide-in-top ${isVisible ? "visible" : ""} stagger-5 hover:shadow-xl transition-shadow`}
        >
          <div className="max-w-3xl mx-auto space-y-6">
            <Users className="h-16 w-16 mx-auto text-white/90" />
            <h3 className="text-3xl lg:text-4xl font-bold">¡No enfrentes tus deudas solo!</h3>
            <p className="text-xl text-white/90 leading-relaxed">
              Nuestro equipo de abogados especialistas está listo para ayudarte. Primera consulta completamente gratuita
              y sin compromiso.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
              <Button
                size="lg"
                onClick={() => (window.location.href = "tel:+56951769304")}
                className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8 py-4 hover:shadow-lg transition-all"
              >
                <Phone className="mr-2 h-5 w-5" />
                Llamar Ahora: +56 9 5176 9304
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={handleWhatsAppClick}
                className="border-white text-white hover:bg-white/10 font-semibold text-lg px-8 py-4 hover:shadow-lg transition-all bg-transparent"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Consulta WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
