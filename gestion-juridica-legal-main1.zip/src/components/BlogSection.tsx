import type React from "react"
import { Calendar, User, ArrowRight } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver"

const blogPosts = [
  {
    id: 1,
    title: "5 Señales de que Necesitas Asesoría Legal en Deudas",
    excerpt:
      "Descubre cuándo es el momento correcto para buscar ayuda profesional. En este artículo explicamos las señales de alerta más importantes.",
    author: "Abog. María González",
    date: "15 de Noviembre, 2024",
    category: "Educación",
    readTime: "5 min",
    content:
      "Las deudas pueden ser abrumadoras y es importante saber cuándo pedir ayuda profesional. En este artículo detallamos las principales señales...",
  },
  {
    id: 2,
    title: "Diferencia entre Insolvencia Civil y Quiebra Personal",
    excerpt:
      "Entérate qué diferencia hay entre estos dos procesos legales y cuál podría ser el más adecuado para tu situación financiera.",
    author: "Abog. Carlos Rodríguez",
    date: "12 de Noviembre, 2024",
    category: "Legal",
    readTime: "8 min",
    content:
      "La insolvencia civil y la quiebra personal son dos procesos diferentes. Es importante entender las diferencias para elegir el mejor...",
  },
  {
    id: 3,
    title: "Cómo Negociar Directamente con Acreedores",
    excerpt:
      "Aprende estrategias comprobadas para negociar con tus acreedores y reducir el monto de tu deuda de manera efectiva.",
    author: "Abog. Laura Martínez",
    date: "10 de Noviembre, 2024",
    category: "Consejos",
    readTime: "6 min",
    content:
      "Negociar directamente con acreedores es posible y puede resultar en reducciones significativas. En este artículo compartimos técnicas...",
  },
]

export const BlogSection = () => {
  const { elementRef, isVisible } = useIntersectionObserver()

  return (
    <section id="blog" ref={elementRef as React.RefObject<HTMLElement>} className="py-24 bg-background scroll-mt-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className={`text-center mb-16 slide-in-top ${isVisible ? "visible" : ""}`}>
          <div className="inline-block mb-4">
            <span className="bg-primary/10 text-primary px-4 py-1 rounded-full text-sm font-semibold">
              Blog & Recursos
            </span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Artículos y Consejos Legales
            <span className="text-primary block mt-2">Para tu Tranquilidad Financiera</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Accede a información actualizada, consejos prácticos y novedades en soluciones de deuda. Nuestros abogados
            comparten su experiencia para ayudarte a tomar las mejores decisiones.
          </p>
        </div>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {blogPosts.map((post, index) => (
            <div key={post.id} className={`group slide-in-top ${isVisible ? "visible" : ""} stagger-${index + 1}`}>
              <Card className="h-full overflow-hidden border-border/40 hover:border-primary/20 hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                <div className="p-6 h-full flex flex-col">
                  {/* Category Badge */}
                  <div className="mb-4">
                    <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-semibold">
                      {post.category}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                    {post.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-muted-foreground text-sm mb-6 flex-grow line-clamp-3">{post.excerpt}</p>

                  {/* Meta Information */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 text-xs text-muted-foreground pt-4 border-t border-border">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span className="line-clamp-1">{post.author}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{post.date}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground font-medium">{post.readTime}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="group/btn gap-2 text-primary hover:text-primary hover:bg-primary/10"
                      >
                        Leer
                        <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>

        {/* CTA for more articles */}
        <div className={`text-center slide-in-top ${isVisible ? "visible" : ""} stagger-5`}>
          <Button
            size="lg"
            className="bg-gradient-to-r from-legal-trust-blue to-legal-navy text-white hover:shadow-lg transition-all"
          >
            Ver Todos los Artículos
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
