"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Phone, MessageCircle, Clock, Shield, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver"

export const CTASection = () => {
  const { toast } = useToast()
  const { elementRef, isVisible } = useIntersectionObserver()

  const handleWhatsAppClick = async () => {
    const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Inicio_whatsapp"

    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          timestamp: new Date().toISOString(),
          source: "CTA Button",
          action: "whatsapp_click",
          page: window.location.href,
        }),
      })

      if (response.ok) {
        // Redirigir a WhatsApp después de enviar al webhook
        window.open(
          "https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas",
          "_blank",
        )
      }
    } catch (error) {
      console.error("Error al conectar webhook:", error)
      // Redirigir de todas formas
      window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank")
    }
  }
  return (
    <section
      ref={elementRef as React.RefObject<HTMLElement>}
      id="contacto"
      className="py-24 bg-gradient-hero relative overflow-hidden scroll-mt-20"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="absolute top-10 left-10 w-32 h-32 bg-secondary/10 rounded-full blur-xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-40 h-40 bg-accent/10 rounded-full blur-xl animate-pulse delay-1000"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center text-white space-y-8">
          {/* Urgency Header */}
          <div
            className={`inline-flex items-center gap-2 bg-legal-warm-orange/20 backdrop-blur-sm px-4 py-2 rounded-full border border-legal-warm-orange/30 mb-6 slide-in-bottom ${isVisible ? "visible" : ""}`}
          >
            <Clock className="h-5 w-5 text-legal-warm-orange" />
            <span className="text-legal-warm-orange font-semibold">¡Actúa Ahora!</span>
          </div>

          {/* Main Headline */}
          <h2
            className={`text-4xl lg:text-6xl font-bold leading-tight slide-in-bottom ${isVisible ? "visible" : ""} stagger-1`}
          >
            No esperes más para
            <span className="text-secondary block mt-2">recuperar tu tranquilidad</span>
          </h2>

          <p
            className={`text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto slide-in-bottom ${isVisible ? "visible" : ""} stagger-2`}
          >
            Cada día que pases sin actuar, los intereses y problemas crecen. Nuestros abogados están listos para
            ayudarte HOY.
          </p>

          {/* Benefits List */}
          <div className={`grid md:grid-cols-3 gap-6 py-8 slide-in-bottom ${isVisible ? "visible" : ""} stagger-3`}>
            <div className="flex items-center gap-3 text-left">
              <CheckCircle className="h-8 w-8 text-accent flex-shrink-0" />
              <div>
                <div className="font-bold text-lg">Consulta Inmediata</div>
                <div className="text-white/80">Sin costo ni compromiso</div>
              </div>
            </div>
            <div className="flex items-center gap-3 text-left">
              <Shield className="h-8 w-8 text-accent flex-shrink-0" />
              <div>
                <div className="font-bold text-lg">Protección Legal</div>
                <div className="text-white/80">Defendemos tus derechos</div>
              </div>
            </div>
            <div className="flex items-center gap-3 text-left">
              <Clock className="h-8 w-8 text-accent flex-shrink-0" />
              <div>
                <div className="font-bold text-lg">Resultados Rápidos</div>
                <div className="text-white/80">Soluciones en semanas</div>
              </div>
            </div>
          </div>

          {/* Main CTAs */}
          <div
            className={`flex flex-col sm:flex-row gap-6 justify-center pt-8 slide-in-bottom ${isVisible ? "visible" : ""} stagger-4`}
          >
            <Button
              size="lg"
              className="bg-legal-warm-orange hover:bg-legal-warm-orange/90 text-white font-bold text-xl px-12 py-6 rounded-xl shadow-strong transition-all duration-300 hover:scale-105"
            >
              <Phone className="mr-3 h-6 w-6" />
              Llamar: +56 9 5176 9304
            </Button>
            <Button
              size="lg"
              onClick={handleWhatsAppClick}
              className="bg-accent hover:bg-accent/90 text-white font-bold text-xl px-12 py-6 rounded-xl shadow-strong transition-all duration-300 hover:scale-105"
            >
              <MessageCircle className="mr-3 h-6 w-6" />
              WhatsApp Directo
            </Button>
          </div>

          {/* Trust Elements */}
          <div
            className={`grid grid-cols-2 md:grid-cols-4 gap-6 pt-12 border-t border-white/20 slide-in-bottom ${isVisible ? "visible" : ""} stagger-5`}
          >
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">24/7</div>
              <div className="text-sm text-white/80">Disponibilidad</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">15+</div>
              <div className="text-sm text-white/80">Años experiencia</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">95%</div>
              <div className="text-sm text-white/80">Casos exitosos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">1000+</div>
              <div className="text-sm text-white/80">Clientes liberados</div>
            </div>
          </div>

          {/* Final Message */}
          <div
            className={`bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 mt-12 fade-scale-in ${isVisible ? "visible" : ""} stagger-6`}
          >
            <p className="text-lg font-medium text-white/95 mb-4">
              "Tu tranquilidad financiera no puede esperar más. Cada minuto cuenta cuando se trata de proteger tu
              patrimonio y tu familia."
            </p>
            <p className="text-secondary font-bold">- Equipo Legal Gestión Jurídica</p>
          </div>
        </div>
      </div>
    </section>
  )
}
