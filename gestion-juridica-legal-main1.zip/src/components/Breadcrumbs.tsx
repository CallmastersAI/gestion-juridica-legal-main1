export const Breadcrumbs = ({ current }: { current: string }) => {
  return (
    <nav className="bg-muted/50 py-4 sticky top-16 z-40" aria-label="Breadcrumb">
      <div className="container mx-auto px-4">
        <ol className="flex items-center gap-2 text-sm">
          <li>
            <a href="#inicio" className="text-primary hover:underline">
              Inicio
            </a>
          </li>
          {current && (
            <>
              <li className="text-muted-foreground">/</li>
              <li className="text-muted-foreground">{current}</li>
            </>
          )}
        </ol>
      </div>
    </nav>
  )
}
