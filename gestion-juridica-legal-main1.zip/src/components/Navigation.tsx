"use client"

import { useState } from "react"
import { Menu, X, Phone, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  // Track scroll for navbar styling
  if (typeof window !== "undefined") {
    window.addEventListener("scroll", () => {
      setIsScrolled(window.scrollY > 50)
    })
  }

  const navLinks = [
    { label: "Inicio", href: "#inicio" },
    { label: "Servicios", href: "#servicios" },
    { label: "Por Qué Nosotros", href: "#porquenos" },
    { label: "Testimonios", href: "#testimonios" },
    { label: "Preguntas", href: "#preguntas" },
    { label: "Contacto", href: "#contacto" },
  ]

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsOpen(false)
    }
  }

  return (
    <>
      {/* Main Navbar */}
      <nav
        className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled ? "bg-white/95 backdrop-blur-md shadow-md" : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16 lg:h-20">
            {/* Logo */}
            <a
              href="#inicio"
              onClick={(e) => {
                e.preventDefault()
                handleNavClick("#inicio")
              }}
              className="flex items-center gap-2 group"
            >
              <div
                className={`flex items-center gap-2 p-2 rounded-lg transition-all ${
                  isScrolled ? "bg-primary/10" : "bg-white/10"
                }`}
              >
                <div className={`font-bold text-lg ${isScrolled ? "text-primary" : "text-white"}`}>GJ</div>
              </div>
              <span className={`font-bold text-lg transition-colors ${isScrolled ? "text-primary" : "text-white"}`}>
                Gestión Jurídica
              </span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link.href)}
                  className={`text-sm font-medium transition-colors hover:text-primary ${
                    isScrolled ? "text-foreground" : "text-white"
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* CTA Buttons - Desktop */}
            <div className="hidden lg:flex items-center gap-3">
              <Button
                size="sm"
                onClick={() => (window.location.href = "tel:+56951769304")}
                variant="ghost"
                className={`flex items-center gap-2 ${
                  isScrolled ? "text-primary hover:bg-primary/10" : "text-white hover:bg-white/10"
                }`}
              >
                <Phone className="h-4 w-4" />
                Llamar
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  window.open(
                    "https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas",
                    "_blank",
                  )
                }}
                className="bg-[#25D366] hover:bg-[#20BA5A] text-white flex items-center gap-2"
              >
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`lg:hidden p-2 ${isScrolled ? "text-foreground" : "text-white"}`}
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className={`lg:hidden ${isScrolled ? "bg-white" : "bg-legal-navy"}`}>
            <div className="container mx-auto px-4 py-4 space-y-4">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link.href)}
                  className={`block w-full text-left py-2 font-medium transition-colors ${
                    isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
                  }`}
                >
                  {link.label}
                </button>
              ))}
              <div className="pt-4 space-y-2 border-t border-border">
                <Button
                  size="sm"
                  onClick={() => (window.location.href = "tel:+56951769304")}
                  className="w-full bg-primary text-white hover:bg-primary/90 flex items-center justify-center gap-2"
                >
                  <Phone className="h-4 w-4" />
                  Llamar Ahora
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    window.open(
                      "https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas",
                      "_blank",
                    )
                  }}
                  className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white flex items-center justify-center gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  WhatsApp
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  )
}
