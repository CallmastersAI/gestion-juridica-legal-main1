import type React from "react"
import { Shield, Scale } from "lucide-react"
import { LeadForm } from "./LeadForm"
import heroLawyers from "@/assets/hero-lawyers.jpg"
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver"

export const HeroSection = () => {
  const { elementRef, isVisible } = useIntersectionObserver()

  return (
    <section
      id="inicio"
      ref={elementRef as React.RefObject<HTMLElement>}
      className="relative min-h-screen bg-gradient-hero overflow-hidden scroll-mt-20"
    >
      {/* Background Image */}
      <div className="absolute inset-0 bg-black/40"></div>
      <img
        src={heroLawyers || "/placeholder.svg"}
        alt="Equipo de abogados profesionales especializados en deudas"
        className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
      />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-12 flex flex-col lg:flex-row items-center justify-between min-h-screen">
        {/* Left Content */}
        <div className={`flex-1 text-white space-y-8 max-w-2xl slide-in-left ${isVisible ? "visible" : ""}`}>
          {/* Logo and Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 hover:bg-white/20 transition-all duration-300">
                <Shield className="h-8 w-8 text-secondary" />
                <Scale className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold text-white">Gestión Jurídica</h1>
                <p className="text-xl text-secondary font-medium">Tu tranquilidad financiera es nuestra misión</p>
              </div>
            </div>
          </div>

          {/* Main Headline */}
          <div className="space-y-6">
            <h2 className="text-3xl lg:text-5xl font-bold leading-tight text-white">
              ¡Libérate de las deudas con nuestros
              <span className="text-secondary block mt-2">abogados expertos!</span>
            </h2>

            <p className="text-xl lg:text-2xl text-white/90 font-medium leading-relaxed">
              Te apoyamos con una solución legal a tu medida para que recuperes tu tranquilidad financiera. Con más de
              15 años de experiencia y +1000 clientes liberados.
            </p>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
            <div className="text-center group cursor-pointer">
              <div className="text-3xl font-bold text-secondary group-hover:scale-110 transition-transform">+95%</div>
              <div className="text-sm text-white/80">Casos Exitosos</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div className="text-3xl font-bold text-secondary group-hover:scale-110 transition-transform">+1000</div>
              <div className="text-sm text-white/80">Clientes Liberados</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div className="text-3xl font-bold text-secondary group-hover:scale-110 transition-transform">15+</div>
              <div className="text-sm text-white/80">Años Experiencia</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div className="text-3xl font-bold text-secondary group-hover:scale-110 transition-transform">24h</div>
              <div className="text-sm text-white/80">Respuesta Rápida</div>
            </div>
          </div>
        </div>

        {/* Right Content - Lead Form */}
        <div className={`flex-shrink-0 mt-8 lg:mt-0 lg:ml-12 slide-in-right ${isVisible ? "visible" : ""}`}>
          <LeadForm />
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-secondary/10 rounded-full blur-xl animate-pulse"></div>
      <div className="absolute bottom-40 right-20 w-32 h-32 bg-accent/10 rounded-full blur-xl animate-pulse delay-1000"></div>
    </section>
  )
}
