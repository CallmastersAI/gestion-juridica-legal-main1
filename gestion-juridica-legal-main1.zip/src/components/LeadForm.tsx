"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, CheckCircle, MessageCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { trackFormSubmission, trackCTAClick } from "@/components/Analytics"

const LeadForm = () => {
  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    telefono: "",
    email: "",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Added analytics tracking for form submission
    trackFormSubmission("lead_form", ["nombre", "apellido", "telefono", "email"])

    const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Formulario_datos"

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nombre: formData.nombre,
          apellido: formData.apellido,
          telefono: formData.telefono,
          email: formData.email,
          timestamp: new Date().toISOString(),
          source: "Lead Form",
          page: window.location.href,
        }),
      })

      toast({
        title: "¡Formulario enviado!",
        description: "Nos contactaremos contigo en las próximas horas.",
        className: "bg-accent text-accent-foreground",
      })

      // Reset form after submission
      setFormData({
        nombre: "",
        apellido: "",
        telefono: "",
        email: "",
      })
    } catch (error) {
      console.error("Error al enviar datos:", error)
      toast({
        title: "¡Formulario enviado!",
        description: "Nos contactaremos contigo en las próximas horas.",
        className: "bg-accent text-accent-foreground",
      })
    }
  }

  const handleWhatsAppClick = async () => {
    // Added analytics tracking for WhatsApp CTA
    trackCTAClick("lead_form_whatsapp", "whatsapp_click")

    const webhookUrl = "https://laboral-n8n.wvg3s7.easypanel.host/webhook/Inicio_whatsapp"

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          timestamp: new Date().toISOString(),
          source: "Lead Form",
          action: "whatsapp_click",
          page: window.location.href,
        }),
      })

      window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank")
    } catch (error) {
      console.error("Error al conectar webhook:", error)
      window.open("https://wa.me/56951769304?text=Hola,%20necesito%20asesoría%20legal%20sobre%20mis%20deudas", "_blank")
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <Card className="w-full max-w-md bg-card shadow-strong border-border/20 hover:shadow-xl transition-all">
      <CardHeader className="text-center">
        <CardTitle className="text-xl font-bold text-foreground">¡Hablemos!</CardTitle>
        <CardDescription className="text-muted-foreground">
          Tu primera consulta es <span className="text-accent font-semibold">sin costo</span> y sin compromiso
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="nombre" className="text-sm font-medium">
                Nombre*
              </Label>
              <Input
                id="nombre"
                name="nombre"
                value={formData.nombre}
                onChange={handleChange}
                placeholder="Tu nombre"
                required
                className="bg-background hover:border-primary/50 transition-colors focus:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apellido" className="text-sm font-medium">
                Apellido*
              </Label>
              <Input
                id="apellido"
                name="apellido"
                value={formData.apellido}
                onChange={handleChange}
                placeholder="Tu apellido"
                required
                className="bg-background hover:border-primary/50 transition-colors focus:ring-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="telefono" className="text-sm font-medium">
              Teléfono Celular*
            </Label>
            <Input
              id="telefono"
              name="telefono"
              type="tel"
              value={formData.telefono}
              onChange={handleChange}
              placeholder="+56 9 XXXX XXXX"
              required
              className="bg-background hover:border-primary/50 transition-colors focus:ring-primary"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-sm font-medium">
              Correo electrónico*
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
              className="bg-background hover:border-primary/50 transition-colors focus:ring-primary"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              onClick={() => {
                trackCTAClick("lead_form_phone", "phone_call")
                window.location.href = "tel:+56951769304"
              }}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6 flex flex-col items-center justify-center h-auto min-h-[80px] transition-all hover:shadow-lg hover:scale-105 active:scale-95"
            >
              <Phone className="h-5 w-5 mb-1" />
              <span className="text-xs leading-tight text-center">
                Llamar Ahora:
                <br />
                +56 9 5176 9304
              </span>
            </Button>

            <Button
              type="button"
              onClick={handleWhatsAppClick}
              className="bg-[#25D366] hover:bg-[#20BA5A] text-white font-semibold py-6 flex flex-col items-center justify-center h-auto min-h-[80px] transition-all hover:shadow-lg hover:scale-105 active:scale-95"
            >
              <MessageCircle className="h-5 w-5 mb-1" />
              <span className="text-xs leading-tight text-center">
                Consulta
                <br />
                WhatsApp
              </span>
            </Button>
          </div>

          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground p-3 bg-accent/5 rounded-lg">
            <CheckCircle className="h-4 w-4 text-accent" />
            <span>Respuesta inmediata por WhatsApp</span>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

export default LeadForm
