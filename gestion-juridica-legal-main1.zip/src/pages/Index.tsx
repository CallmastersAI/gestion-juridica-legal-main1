import { Navigation } from "@/components/Navigation"
import { HeroSection } from "@/components/HeroSection"
import { ServicesSection } from "@/components/ServicesSection"
import { TestimonialsSection } from "@/components/TestimonialsSection"
import { FAQSection } from "@/components/FAQSection"
import { CTASection } from "@/components/CTASection"
import { BlogSection } from "@/components/BlogSection"
import { Footer } from "@/components/Footer"
import { Analytics } from "@/components/Analytics"

const Index = () => {
  return (
    <main className="min-h-screen">
      <Analytics />
      <Navigation />
      <HeroSection />
      <ServicesSection />
      <BlogSection />
      <TestimonialsSection />
      <FAQSection />
      <CTASection />
      <Footer />
    </main>
  )
}

export default Index
